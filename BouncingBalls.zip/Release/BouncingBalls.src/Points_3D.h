#pragma once
class Points_3D
{
public:
	float x, y, z;

	Points_3D(void);
	Points_3D(float x, float y, float z);
	~Points_3D(void);
};

