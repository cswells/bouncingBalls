#include "Points_3D.h"


Points_3D::Points_3D(void)
{
}

Points_3D::Points_3D(float x, float y, float z)
{
	this->x = x;
	this->y = y;
	this->z = z;
}

Points_3D::~Points_3D(void)
{
}
