#pragma once
#include "CollisionHandlerTreeNode.h"
class CollisionHandlerTree
{
public:
	CollisionHandlerTree(void);
	~CollisionHandlerTree(void);

private:
	CollisionHandlerTreeNode *root;
	

};

