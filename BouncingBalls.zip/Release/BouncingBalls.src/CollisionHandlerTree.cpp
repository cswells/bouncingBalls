#include "CollisionHandlerTree.h"


CollisionHandlerTree::CollisionHandlerTree(void)
{
}


CollisionHandlerTree::~CollisionHandlerTree(void)
{
}
